João Victor Dell Agli Floriano - 10799783
Sistemas Operacionais - 2022.1

Execução: bash shell.sh